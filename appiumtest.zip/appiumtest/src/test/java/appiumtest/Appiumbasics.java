package appiumtest;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;

import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class Appiumbasics {
	
	@Test
	public void baseSetup() throws MalformedURLException, URISyntaxException {
		
		UiAutomator2Options option = new UiAutomator2Options();
		option.setDeviceName("AndroidDevice");
		option.setApp("//Users//vijaya.bonthu//eclipse-workspace//appiumtest//src//test//java//resources//ApiDemos-debug.apk");
		
		
		AndroidDriver driver = new AndroidDriver(new URI("http://127.0.0.1:4723").toURL(), option);
	
	}

}
