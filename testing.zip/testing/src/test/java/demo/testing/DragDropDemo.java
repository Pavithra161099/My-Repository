package demo.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;

/*
 * add test annotation above class name
 * 1. create android driver object
 * 2. add URL with port
 * 3. create object for UiAutomator2Options and set device name using it.
 * 4. create separate package and add APK file in it.
 * 5. set app name using automator object.(*make sure the URL it double slash)
 * 6. start and stop appium programmatically using AppiumServiceBuilder
 * 7. we should add main.js path with Appium (that path is string so we have to convert into file using new File())
 * 8. add IP address and port using withIPAddress and usingPort method. and finally build it using build()
 * 9. start and stop the service using start() & stop() methods
 * 10. appium inspector- identify elements on the apps
 * 11. appium supports following locators- xpath id, id, accessibility id, classname, androidUIAutomator
 * 12. find element locators by using appium inspector
 * 13. create base class and add the appium server code and driver code.(all common code are patched in single class)
 * 14.  we can use UiScrollable class sfor scrolling.
		 * here, UiScrollable is a class in google engine of UIAutomator
		 * UiSelector is an argument
		 * UiScrollable class has method of scrollIntoView(). it accepts the text in mobile UI, 
		 * so we are writing our text inside text ()
  */
 
 
public class DragDropDemo extends BaseClass  {
 
	@Test
	public void dragDropDemotest() throws InterruptedException  
	{
		
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		
		driver.findElement(AppiumBy.accessibilityId("Drag and Drop")).click();
		
		WebElement source = driver.findElement(By.id("io.appium.android.apis:id/drag_dot_1"));
		
		dragDropAction(source, 826, 796);
		
		
		Thread.sleep(2000);
		
		String result = driver.findElement(By.id("io.appium.android.apis:id/drag_result_text")).getText();
		
		Assert.assertEquals(result, "Dropped!");
		
		

		
		
		
		
		
		
	}
}
