package demo.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;

/*
 * add test annotation above class name
 * 1. create android driver object
 * 2. add URL with port
 * 3. create object for UiAutomator2Options and set device name using it.
 * 4. create separate package and add APK file in it.
 * 5. set app name using automator object.(*make sure the URL it double slash)
 * 6. start and stop appium programmatically using AppiumServiceBuilder
 * 7. we should add main.js path with Appium (that path is string so we have to convert into file using new File())
 * 8. add IP address and port using withIPAddress and usingPort method. and finally build it using build()
 * 9. start and stop the service using start() & stop() methods
 * 10. appium inspector- identify elements on the apps
 * 11. appium supports following locators- xpath id, id, accessibility id, classname, androidUIAutomator
 * 12. find element locators by using appium inspector
 * 13. create base class and add the appium server code and driver code.(all common code are patched in single class)
 * 14.  we can use UiScrollable class sfor scrolling.
		 * here, UiScrollable is a class in google engine of UIAutomator
		 * UiSelector is an argument
		 * UiScrollable class has method of scrollIntoView(). it accepts the text in mobile UI, 
		 * so we are writing our text inside text ()
  */
 
 
public class Practice1 extends BaseClass  {
 
	@Test
	public void dragDropDemotest() throws InterruptedException   
	{
		
		
	
		driver.findElement(AppiumBy.accessibilityId("App")).click();
		
		driver.findElement(AppiumBy.accessibilityId("Alert Dialogs")).click();
		
		/*
		//1st button test
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons")).click();
		
		//OK button
		driver.findElement(By.id("android:id/button1")).click();
		
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons")).click();
		
		//Cancel button
		driver.findElement(By.id("android:id/button2")).click();
		
		
		//2nd button test
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons2")).click();
		
		String alertTitle = driver.findElement(By.id("android:id/alertTitle")).getText();
		
		Assert.assertEquals(alertTitle, "Header title");
		
		//OK button
		driver.findElement(By.id("android:id/button1")).click();
		
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons2")).click();
		
		//Cancel button
		driver.findElement(By.id("android:id/button2")).click();
		
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons2")).click();
		
		//Something button
		driver.findElement(By.id("android:id/button3")).click();
		

		
		//3rd button test
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons2ultra")).click();
		
		String alertTitle2 = driver.findElement(By.id("android:id/alertTitle")).getText();
		
		Assert.assertEquals(alertTitle2, "Header title");
		
		//OK button
		driver.findElement(By.id("android:id/button1")).click();
				
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons2ultra")).click();
				
		//Cancel button
		driver.findElement(By.id("android:id/button2")).click();
				
		driver.findElement(By.id("io.appium.android.apis:id/two_buttons2ultra")).click();
				
		//Something button
		driver.findElement(By.id("android:id/button3")).click();
		
		
		
		
		//4th button test
		
		driver.findElement(By.id("io.appium.android.apis:id/text_entry_button")).click();	
		
		String dialogText = driver.findElement(By.id("android:id/alertTitle")).getText();
		
		Assert.assertEquals(dialogText, "Text Entry dialog");
		
		String nameField = driver.findElement(By.id("io.appium.android.apis:id/username_view")).getText();
		
		Assert.assertEquals(nameField, "Name:");
		
		String passwordField = driver.findElement(By.id("io.appium.android.apis:id/password_view")).getText();
		
		Assert.assertEquals(passwordField, "Password:");
		
		//OK button- input type
		
		driver.findElement(By.id("io.appium.android.apis:id/username_edit")).sendKeys("username");
		driver.findElement(By.id("io.appium.android.apis:id/password_edit")).sendKeys("userpassword");
		
		driver.findElement(By.id("android:id/button1")).click();	
		
		//Cancel button
		driver.findElement(By.id("io.appium.android.apis:id/text_entry_button")).click();
		driver.findElement(By.id("io.appium.android.apis:id/username_edit")).sendKeys("testuser");
		driver.findElement(By.id("io.appium.android.apis:id/password_edit")).sendKeys("Pass@123");
		
		driver.findElement(By.id("android:id/button2")).click();
		
		
		*/
		//5th button test- progress bar
		driver.findElement(By.id("io.appium.android.apis:id/progress_button")).click();
		
		//driver.findElement(By.id("io.appium.android.apis:id/checkbox_button2")).click();
		
		
		/*
		
		//5th button- list dialog
		driver.findElement(By.id("io.appium.android.apis:id/select_button")).click();
		
		String headertitle = driver.findElement(By.id("android:id/alertTitle")).getText();
		Assert.assertEquals(headertitle, "Header title");
		
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text='Command one']")).click();
		
		
		String result = driver.findElement(By.id("android:id/message")).getText();
		Assert.assertEquals(result, "You selected: 0 , Command one");
		
		
		
		//6th button test- radio button
		
		
		
		driver.findElement(By.id("io.appium.android.apis:id/radio_button")).click();
		
		driver.findElement(AppiumBy.xpath("//android.widget.CheckedTextView[@text='Traffic']")).click();
		
		
		
		driver.findElement(By.id("android:id/button1")).click();
		*/
		
		Thread.sleep(3000);
		
		
		
		
		
	}
}
