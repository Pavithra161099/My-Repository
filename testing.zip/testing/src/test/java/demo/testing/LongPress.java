package demo.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;

/*
 * add test annotation above class name
 * 1. create android driver object
 * 2. add URL with port
 * 3. create object for UiAutomator2Options and set device name using it.
 * 4. create separate package and add APK file in it.
 * 5. set app name using automator object.(*make sure the URL it double slash)
 * 6. start and stop appium programmatically using AppiumServiceBuilder
 * 7. we should add main.js path with Appium (that path is string so we have to convert into file using new File())
 * 8. add IP address and port using withIPAddress and usingPort method. and finally build it using build()
 * 9. start and stop the service using start() & stop() methods
 * 10. appium inspector- identify elements on the apps
 * 11. appium supports following locators- xpath id, id, accessibility id, classname, androidUIAutomator
 * 12. find element locators by using appium inspector
 * 13. create base class and add the appium server code and driver code.(all common code are patched in single class)
 */
 
public class LongPress extends BaseClass  {
 
	@Test
	public void longPressGesture() throws InterruptedException   
	{
		
		driver.findElement(AppiumBy.accessibilityId("Views")).click();
		
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"Expandable Lists\"]")).click();
		
		driver.findElement(AppiumBy.accessibilityId("1. Custom Adapter")).click();
		
		WebElement ele = driver.findElement(By.xpath("//android.widget.TextView[@text='People Names']"));
		longPressAction(ele);
		
		
		String menuText = driver.findElement(By.id("android:id/title")).getText();
		Assert.assertEquals(menuText, "Sample menu");
		Assert.assertTrue(driver.findElement(By.id("android:id/title")).isDisplayed());
		
		
		//Thread.sleep(2000);
		
		
		
		
		
		
	}
}
