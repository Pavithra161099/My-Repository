package demo.testing;


	

	import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

	import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.opentelemetry.api.internal.StringUtils;

	 
	public class AndroidQaApp extends BaseClass  {
	 
		@Test
		public void test() throws InterruptedException   
		{
			
			
			// configure parameters
			driver.findElement(AppiumBy.id("com.nec.biometrics:id/config_sdk_params_btn")).click();
			driver.findElement(AppiumBy.id("com.nec.biometrics:id/domain_url_edt")).sendKeys("https://sdkgltenant.ndpapp2.necdp.com/idms");
			driver.findElement(By.id("com.nec.biometrics:id/user_id_edt")).sendKeys("mobilegluser");
			driver.findElement(By.id("com.nec.biometrics:id/user_pass_edt")).sendKeys("P@ssword1");
			driver.findElement(By.id("com.nec.biometrics:id/dictionary_url_edt")).sendKeys("https://webserver.ndpapp2.necdp.com/neoface");
			driver.findElement(By.id("com.nec.biometrics:id/username_edt")).sendKeys("ndp");
			driver.findElement(By.id("com.nec.biometrics:id/pass_edt")).sendKeys("Passw0rd!");
			driver.findElement(By.id("com.nec.biometrics:id/livenessTypeSpinner")).sendKeys("NFGL");
			
			//save configuration
			driver.findElement(By.id("com.nec.biometrics:id/save_btn")).click();
			
			//click SDK INIT button
			driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();
			
			System.out.println("The dictionary files will take some time to download, So Please wait...");
			
			WebElement ele1 = driver.findElement(By.id("com.nec.biometrics:id/download_status_tv"));
			
			
			//waiting until the dictionary file download
			
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(500));
			
			wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
			Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");
				
			
			/*
			 * to get app activity---adb shell dumpsys window |grep -E 'mCurrentFocus|mFocusedApp' 
			 * Activity activity = new Activity("com.nec.biometrics", "com.nec.qa.ui.MainActivity");
			 * driver.startActivity(activity);// this startActivity method was removed from code
			 */
			
			

			/*
			driver.findElement(By.xpath("(//android.widget.Button[@resource-id='com.nec.biometrics:id/scan_btn'])[1]")).click();
			
			driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_foreground_only_button")).click();
			
			System.out.println("Scan your face...");
			
			driver.pressKey(new KeyEvent(AndroidKey.BACK));
			
			driver.findElement(By.xpath("(//android.widget.Button[@resource-id='com.nec.biometrics:id/scan_btn'])[2]")).click();
			
			driver.findElement(By.id("com.nec.biometrics:id/passport_scan")).click();
			
			System.out.println("Downloading document scan DB, So Please wait...");
			
			WebElement ele2 = driver.findElement(By.id("com.nec.biometrics:id/title_view"));
			
			//waiting until the document file to be downloaded
			
			WebDriverWait wait2 = new WebDriverWait(driver,Duration.ofSeconds(500));
			
			wait2.until(ExpectedConditions.textToBePresentInElement(ele2, "Doc scan DB downloading: 100%"));
			Assert.assertEquals(ele2.getText(), "Doc scan DB downloading: 100%");
			
			System.out.println("Scan your Passport/Driver license...");
					
			driver.pressKey(new KeyEvent(AndroidKey.BACK));
			
			*/
			
			driver.findElement(By.id("com.nec.biometrics:id/submit_btn")).click();
			
			
			String text = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getAttribute("text");
			
			Assert.assertEquals(text, "Face details not available");
			
			
			
			driver.findElement(By.id("com.nec.biometrics:id/img_btn1")).click();
			
			//driver.findElement(By.xpath("//android.widget.imageView[@contenat-desc='20231221_155219.jpg']")).click();
			
			driver.findElement(By.xpath("(//android.widget.ImageView[@resource-id='com.google.android.providers.media.module:id/icon_thumbnail'])[11]")).click();
			
			driver.findElement(By.id("com.nec.biometrics:id/img_btn2")).click();
			
			driver.findElement(By.xpath("(//android.widget.ImageView[@resource-id='com.google.android.providers.media.module:id/icon_thumbnail'])[11]")).click();
			
			driver.findElement(By.id("com.nec.biometrics:id/local_verify_btn")).click();
			
			String text2 = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getAttribute("text");
			
			Assert.assertEquals(text2, "true");
			
			driver.findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"VERIFY LOCAL 1:1 WITH WALLET\"));"));
			
			driver.findElement(By.id("com.nec.biometrics:id/btn_wallet_image")).click();
			
			driver.findElement(By.xpath("(//android.widget.ImageView[@resource-id='com.google.android.providers.media.module:id/icon_thumbnail'])[11]")).click();
			
			driver.findElement(By.id("com.nec.biometrics:id/local_verify_with_wallet_btn")).click();
			
			
			Thread.sleep(6000);
	
			
		}

		
	}

