package demo.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.DeviceRotation;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

/*
 * add test annotation above class name
 * 1. create android driver object
 * 2. add URL with port
 * 3. create object for UiAutomator2Options and set device name using it.
 * 4. create separate package and add APK file in it.
 * 5. set app name using automator object.(*make sure the URL it double slash)
 * 6. start and stop appium programmatically using AppiumServiceBuilder
 * 7. we should add main.js path with Appium (that path is string so we have to convert into file using new File())
 * 8. add IP address and port using withIPAddress and usingPort method. and finally build it using build()
 * 9. start and stop the service using start() & stop() methods
 * 10. appium inspector- identify elements on the apps
 * 11. appium supports following locators- xpath id, id, accessibility id, classname, androidUIAutomator
 * 12. find element locators by using appium inspector
 * 13. create base class and add the appium server code and driver code.(all common code are patched in single class)
 */
 
public class MisceallanousAppiumActions extends BaseClass  {
 
	@Test
	public void misceallanous() throws InterruptedException   
	{ 
		
	
		
		//adb shell dumpsys window | grep -E 'mCurrrentFocus' - MAC-adb shell dumpsys window |grep -E 'mCurrentFocus|mFocusedApp'  

		//adb shell dumpsys window | find 'mCurrrentFocus' - WINDOW
		
		//Activity activity = new Activity("io.appium.android.apis", "io.appium.android.apis.preference.PreferenceDependencies");
	
		//driver.startActivity(activity);// this startActivity method was removed from code
		
		
		
		/*
		 * These below 2 steps are navigating step by step. But whereas we can directly navigate
		 *  to the page where we want by using activity class.
		 * 
		driver.findElement(AppiumBy.accessibilityId("Preference")).click();
		driver.findElement(By.xpath("//android.widget.TextView[@content-desc=\"3. Preference dependencies\"]")).click();
		*/
		driver.findElement(By.id("android:id/checkbox")).click();
		
		DeviceRotation landScape = new DeviceRotation(0, 0, 90);
		driver.rotate(landScape);
		
		
		driver.findElement(By.xpath("(//android.widget.RelativeLayout)[2]")).click();
		
		String alertTitle =  driver.findElement(By.id("android:id/alertTitle")).getText();
		
		driver.pressKey(new KeyEvent(AndroidKey.ENTER));
		
		 Thread.sleep(2000);
		 
		Assert.assertEquals(alertTitle, "WiFi settings");
		
		driver.setClipboardText("Wifi");//copy the content in clip board
		
		driver.findElement(By.id("android:id/edit")).sendKeys(driver.getClipboardText());//paste the text from clip board
		driver.findElements(AppiumBy.className("android.widget.Button")).get(1).click();
		
		driver.pressKey(new KeyEvent(AndroidKey.BACK));
		
		
		driver.pressKey(new KeyEvent(AndroidKey.HOME));
		
	 Thread.sleep(4000);
	 
		
		
		
		
		
		
		
		
		
	}
}
