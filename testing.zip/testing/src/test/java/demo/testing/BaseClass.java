package demo.testing;

import java.io.File;
import java.net.URL;
import java.time.Duration;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class BaseClass  {
	
	
	public AppiumDriverLocalService service;
	public AndroidDriver driver;
	
 
	@BeforeClass
	public void configureAppium() throws MalformedURLException, URISyntaxException 
	{
		
		//Making connection with appium server
		service = new AppiumServiceBuilder().withAppiumJS(new File("//usr/local//lib//node_modules//appium//build//lib//main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).build();
		System.out.println("*****   Starting Appium server   *****");
		//service.start();
		
		UiAutomator2Options options = new UiAutomator2Options();
		//options.setDeviceName("emulator1");
		options.setDeviceName("Android Device");
		options.setApp("//Users//vijaya.bonthu//eclipse-workspace//testing//src//test//java//resources//ApiDemos-debug.apk");
		
		
		
		//options.setApp("//Users//vijaya.bonthu//eclipse-workspace//testing//src//test//java//resources//qa-app-release_nfgl_aarfiles (1).apk");
		
		
		driver = new AndroidDriver(new URI("http://127.0.0.1:4723").toURL(), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); //here i have used implicit wait to load the app

	}
	
	public void longPressAction(WebElement ele) {

		((JavascriptExecutor)driver).executeScript("mobile: longClickGesture", 
				ImmutableMap.of("elementId", ((RemoteWebElement)ele).getId(),
				"duration", 2000));
	}
	
	
	
	public void scrollToEndAction() {
		boolean canScrollMore;
		
		do{
		 canScrollMore = (Boolean) ((JavascriptExecutor) driver).executeScript("mobile: scrollGesture", ImmutableMap.of(
			    "left", 100, "top", 100, "width", 200, "height", 200,
			    "direction", "down",
			    "percent", 3.0
			));
		
		}while(canScrollMore);
	}
		
	
	public void swipeAction(WebElement ele, String direction ) {

		((JavascriptExecutor)driver).executeScript("mobile: swipeGesture", 
				ImmutableMap.of("elementId", ((RemoteWebElement)ele).getId(),
						"direction", direction,
					    "percent", 0.75
					    ));
			
	}
	
	public void dragDropAction(WebElement ele, int x, int y ) {

		((JavascriptExecutor)driver).executeScript("mobile: dragGesture", 
				ImmutableMap.of("elementId", ((RemoteWebElement)ele).getId(),
						"endX", x ,
						"endY", y
						
					    ));
			
	}
	
	
	
	 
		
		@AfterClass
		public void close() {
			System.out.println("#Stopped driver...");
			driver.quit();  //stop the driver
			System.out.println("####....Stopped Appium server....####");
			service.stop(); //stop appium server
		}
		
		
}
