package demo.testing1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class EnrollmentWithFaceOnly extends Base {

	@Test
	public void didEnrollmentwithFaceOnlyTest() throws InterruptedException {

		System.out.println("Installing qa-app on device");
		// configure parameters
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/config_sdk_params_btn")).click();
		System.out.println("Configuring SDK parameters...");
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/domain_url_edt"))
				.sendKeys("https://sdkgltenant.ndpapp2.necdp.com/idms");
		driver.findElement(By.id("com.nec.biometrics:id/user_id_edt")).sendKeys("mobilegluser");
		driver.findElement(By.id("com.nec.biometrics:id/user_pass_edt")).sendKeys("P@ssword1");
		driver.findElement(By.id("com.nec.biometrics:id/dictionary_url_edt"))
				.sendKeys("https://webserver.ndpapp2.necdp.com/neoface");
		driver.findElement(By.id("com.nec.biometrics:id/username_edt")).sendKeys("ndp");
		driver.findElement(By.id("com.nec.biometrics:id/pass_edt")).sendKeys("Passw0rd!");
		driver.findElement(By.id("com.nec.biometrics:id/livenessTypeSpinner")).sendKeys("NFGL");

		// save configuration
		driver.findElement(By.id("com.nec.biometrics:id/save_btn")).click();

		// click SDK INIT button
		driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();

		System.out.println("The dictionary files will take some time to download, So Please wait...");

		WebElement ele1 = driver.findElement(By.id("com.nec.biometrics:id/download_status_tv"));

		// waiting until the dictionary file download

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(600));

		if (ele1.isDisplayed() == true) {
			wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
			Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");
		} else if (driver.findElement(By.id("com.nec.biometrics:id/alertTitle")).isDisplayed() == true) {
			driver.findElement(By.id("android:id/button2")).click();
			System.out.println("The dictionary files will take some time to download, So Please wait...");
			driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();
			wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
			Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");
		} else {
			System.out.println("App terminated due to poor network...");
		}

		driver.findElement(By.id("com.nec.biometrics:id/submit_btn")).click();

		String text = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getAttribute("text");

		Assert.assertEquals(text, "Face details not available");

		// Face scan
		driver.findElement(By.xpath("(//android.widget.Button[@resource-id='com.nec.biometrics:id/scan_btn'])[1]"))
				.click();

		driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_foreground_only_button"))
				.click();

		System.out.println("Scan your face...");

		wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath(
				"//android.widget.TextView[@resource-id=\"com.nec.biometrics:id/face_scan_feedback\" and @text=\"Success\"]"),
				"Success"));

		if (driver.findElement(By.id("com.nec.biometrics:id/retakeBtn")).isDisplayed() == true) {

		}

		driver.findElement(By.id("com.nec.biometrics:id/useBtn")).click();

		System.out.println("Scanned your face successfullly!");

		driver.findElement(By.id("com.nec.biometrics:id/submit_btn")).click();

		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("com.nec.biometrics:id/snackbar_text"))));

		System.out.println(driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getAttribute("text"));

		Thread.sleep(3000);

		// wallet credentials
		driver.findElement(By.id("com.nec.biometrics:id/walletCredentials")).click();

		driver.findElement(AppiumBy.accessibilityId("Preview image")).isDisplayed();

		driver.findElement(By.id("com.nec.biometrics:id/nameTv")).getText().equalsIgnoreCase("FACE");

		driver.findElement(By.id("com.nec.biometrics:id/removeCredentials")).click();

		String removefaceCredResponse = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getText();

		Assert.assertEquals(removefaceCredResponse, "Credential can't removed from wallet");

		driver.pressKey(new KeyEvent(AndroidKey.BACK));

		// Check-in process

		driver.findElement(By.xpath(
				"//android.widget.Button[@resource-id=\'com.nec.biometrics:id/submit_btn\' and @text=\'CHECK IN\']"))
				.click();

		// trying to do check in before entering inputs

		System.out.println("Trying check in before entering details...");
		driver.findElement(By.id("com.nec.biometrics:id/check_in_btn")).click();
		System.out.println(driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getText());
		// System.out.println(driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).getText());

		// reference id
		driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).click();

		driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).clear();

		driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).sendKeys("referenceId1234567");

		// Airport code
		driver.findElement(By.xpath(
				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[1]"))
				.click();
		driver.findElement(By.xpath(
				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[1]"))
				.sendKeys("AAA1");

		// Carrier code
		driver.findElement(By.xpath(
				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[2]"))
				.click();
		driver.findElement(By.xpath(
				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[2]"))
				.sendKeys("Code");

		// effective date
		driver.findElement(By.xpath(
				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[3]"))
				.click();
		driver.findElement(By.xpath(
				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[3]"))
				.sendKeys("2024-01-18T20:30:07Z");

		// Expiry date
		driver.findElement(By.id("com.nec.biometrics:id/expiry_date_et")).click();
		driver.findElement(By.id("com.nec.biometrics:id/expiry_date_et")).clear();
		driver.findElement(By.id("com.nec.biometrics:id/expiry_date_et")).sendKeys("2030-08-25T20:30:07Z");

		// hide keyboard
		driver.hideKeyboard();

		// first name
		driver.findElement(By.id("com.nec.biometrics:id/first_name_et")).click();
		driver.findElement(By.id("com.nec.biometrics:id/first_name_et")).sendKeys("Yogendra");

		// hide keyboard
		driver.hideKeyboard();

		// last name
		driver.findElement(By.id("com.nec.biometrics:id/last_name_et")).click();
		driver.findElement(By.id("com.nec.biometrics:id/last_name_et")).sendKeys("Tiwari");

		// hide keyboard
		driver.hideKeyboard();

		// click check-in button
		driver.findElement(By.id("com.nec.biometrics:id/check_in_btn")).click();

		// wait until the check in successful
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("com.nec.biometrics:id/snackbar_text"))));

		String checkInresponse1 = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getAttribute("text");
		System.out.println(checkInresponse1);

		if (checkInresponse1.equalsIgnoreCase("Datashare request already exists")) {

			System.out.println(
					"Datashare request already exists with referenceId1234567, so updating with new reference Id...");
			driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).click();

			driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).clear();

			driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).sendKeys("referenceId123456");

			driver.hideKeyboard();

			driver.findElement(By.id("com.nec.biometrics:id/check_in_btn")).click();

			wait.until(
					ExpectedConditions.visibilityOf(driver.findElement(By.id("com.nec.biometrics:id/snackbar_text"))));

			String checkInresponse2 = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text"))
					.getAttribute("text");
			System.out.println(checkInresponse2);
		}

		driver.findElement(AppiumBy
				.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"GET TRACE ID\"));"));

		driver.findElement(By.id("com.nec.biometrics:id/btn_trace_id")).click();

		// wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//android.widget.Toast[@text=\'Success,
		// traceId list size is 1\']"))));

		String toastMessage1 = driver.findElement(By.xpath("(//android.widget.Toast)[1]")).getAttribute("text");

		System.out.println(toastMessage1);

		driver.findElement(By.id("com.nec.biometrics:id/tv_hit_api")).click();

		// android.widget.Toast[@text="Success 200"]

		String toastMessage2 = driver.findElement(By.xpath("//android.widget.Toast[@text=\'Success 200\']"))
				.getAttribute("text");

		// String toastMessage2 =
		// driver.findElement(By.xpath("(//android.widget.Toast)[1]")).getAttribute("text");

		System.out.println("Deleted trace Id successfully :) " + toastMessage2);

		driver.pressKey(new KeyEvent(AndroidKey.BACK));

		Thread.sleep(3000);

	}

}
