package demo.testing1;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;


public class Base{
	
	public AndroidDriver driver;
	public AppiumDriverLocalService service;
	
	@BeforeClass
	public void Configure() throws MalformedURLException, URISyntaxException, InterruptedException {
	
	service = new AppiumServiceBuilder().withAppiumJS(new File("//usr//local//lib//node_modules//appium//lib//main.js"))
			.withIPAddress("127.0.0.1").usingPort(4723).build();
	//service.start();  not available in latest Appium
	
	UiAutomator2Options options = new UiAutomator2Options();
	driver = new AndroidDriver(new URI("http://127.0.0.1:4723").toURL(), options);
	
	
	options.setPlatformName("Android");
	options.setDeviceName("AndroidDevice");
	options.setCapability("appPackage", "com.nec.biometrics");
    options.setCapability("appActivity","com.nec.ref.OnBoardingActivity");
	options.setCapability("noReset",true);
	options.setCapability("fullReset",false);
	options.setCapability("autoLaunch",true); 
	options.setCapability("securedScreenInstrument", true);
	
	
    
	if(driver.isAppInstalled("com.nec.biometrics") == true) {
		System.out.println("App already present");
	}else {
	options.setApp("//Users//vijaya.bonthu//eclipse-workspace//RegistrationAppTesting//src//test//java//resources//Registration-app-license-update.apk");

	System.out.println("Application launched on device...");
	

	
	
	}
	
	
	}

	
	@AfterClass
	public void tearDown() {
		service.stop();
		driver.quit();
	}

}
