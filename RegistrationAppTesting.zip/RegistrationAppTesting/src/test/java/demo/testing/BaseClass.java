package demo.testing;

import java.io.File;
import java.net.URL;
import java.time.Duration;
import java.net.MalformedURLException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;



public class BaseClass {

	public AppiumDriverLocalService service;
	public AndroidDriver driver;

	@BeforeClass
	public void configureAppium() throws MalformedURLException {

		// Making connection with appium server
		service = new AppiumServiceBuilder()
				.withAppiumJS(new File("//usr/local//lib//node_modules//appium//build//lib//main.js"))
				.withIPAddress("127.0.0.1").usingPort(4723).build();
		System.out.println("/*****   Starting Appium server   *****/");
	   // service.start();

		UiAutomator2Options options = new UiAutomator2Options();
		//options.setDeviceName("emulator1");
		//options.setDeviceName("RZ8R30L9RGY");
		//options.setDeviceName("MFX8RCWWQ4EM6DZL");
		options.setDeviceName("Android Device");
		options.setApp("/Users/vijaya.bonthu/eclipse-workspace/AndroidQaAppTesting/src/test/java/resources/qa-app-debug.apk");

		//options.setAppPackage("com.nec.biometrics");
		//options.setAppActivity("com.nec.qa.ui.launcher.LauncherActivity");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); // here i have used implicit wait to load the app
																

	}

	@AfterClass
	public void close() {
		System.out.println("#Stopped Android driver...");
		driver.quit(); // stop the driver
		System.out.println("####....Stopped Appium server....####");
		service.stop(); // stop appium server
	}

}
