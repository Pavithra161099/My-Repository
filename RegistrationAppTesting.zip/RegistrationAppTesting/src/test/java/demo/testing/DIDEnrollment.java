package demo.testing;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class DIDEnrollment extends BaseClass {

	@Test
	public void didEnrollmentTest() throws InterruptedException {

		// configure parameters
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/config_sdk_params_btn")).click();
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/domain_url_edt"))
				.sendKeys("https://sdkgltenant.ndpapp2.necdp.com/idms");
		driver.findElement(By.id("com.nec.biometrics:id/user_id_edt")).sendKeys("mobilegluser");
		driver.findElement(By.id("com.nec.biometrics:id/user_pass_edt")).sendKeys("P@ssword1");
		driver.findElement(By.id("com.nec.biometrics:id/dictionary_url_edt"))
				.sendKeys("https://webserver.ndpapp2.necdp.com/neoface");
		driver.findElement(By.id("com.nec.biometrics:id/username_edt")).sendKeys("ndp");
		driver.findElement(By.id("com.nec.biometrics:id/pass_edt")).sendKeys("Passw0rd!");
		driver.findElement(By.id("com.nec.biometrics:id/livenessTypeSpinner")).sendKeys("NFGL");

		// save configuration
		driver.findElement(By.id("com.nec.biometrics:id/save_btn")).click();

		// click SDK INIT button
		driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();

		System.out.println("The dictionary files will take some time to download, So Please wait...");

		WebElement ele1 = driver.findElement(By.id("com.nec.biometrics:id/download_status_tv"));

		// waiting until the dictionary file download

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(500));

		wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
		Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");

		driver.findElement(By.id("com.nec.biometrics:id/submit_btn")).click();

		String text = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getAttribute("text");

		Assert.assertEquals(text, "Face details not available");

		Thread.sleep(3000);
		
		//wallet credentials
//		driver.findElement(By.id("com.nec.biometrics:id/submit_btn")).click();
//
//		driver.findElement(By.id("com.nec.biometrics:id/scan_btn")).click();
//
//		WebElement ele3 = driver.findElement(By.id("com.nec.biometrics:id/title_view"));
//
//		// waiting until the document file to be downloaded
//
//		wait.until(ExpectedConditions.textToBePresentInElement(ele3, "Doc scan DB downloading: 100%"));
//
//		driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_foreground_only_button"))
//				.click();
//
//		System.out.println("Scan your Passport/Driver License document...");
//
//		driver.findElement(By.id("com.nec.biometrics:id/use_document")).click();

		System.out.println("Doing check in again...");
//		driver.findElement(By.xpath(
//				"//android.widget.Button[@resource-id=\'com.nec.biometrics:id/submit_btn\' and @text=\'CHECK IN\']"))
//				.click();
//
//		driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).click();
//		driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).clear();
//		driver.findElement(By.id("com.nec.biometrics:id/ref_id_et")).sendKeys("referenceId1234567");
//		driver.findElement(By.xpath(
//				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[1]"))
//				.click();
//		driver.findElement(By.xpath(
//				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[1]"))
//				.sendKeys("AAA1");
//		driver.findElement(By.xpath(
//				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[2]"))
//				.click();
//		driver.findElement(By.xpath(
//				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[2]"))
//				.sendKeys("Code");
//		driver.findElement(By.xpath(
//				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[3]"))
//				.click();
//		driver.findElement(By.xpath(
//				"//android.widget.LinearLayout[@resource-id=\'com.nec.biometrics:id/event_details_view\']/android.widget.EditText[3]"))
//				.sendKeys("2024-01-18T20:30:07Z");
//		driver.findElement(By.id("com.nec.biometrics:id/expiry_date_et")).click();
//		driver.findElement(By.id("com.nec.biometrics:id/expiry_date_et")).clear();
//		driver.findElement(By.id("com.nec.biometrics:id/expiry_date_et")).sendKeys("2030-08-25T20:30:07Z");
//		driver.hideKeyboard();
//		driver.findElement(By.id("com.nec.biometrics:id/first_name_et")).click();
//		driver.findElement(By.id("com.nec.biometrics:id/first_name_et")).sendKeys("Yogendra");
//		driver.hideKeyboard();
//		driver.findElement(By.id("com.nec.biometrics:id/last_name_et")).click();
//		driver.findElement(By.id("com.nec.biometrics:id/last_name_et")).sendKeys("Tiwari");
//		driver.hideKeyboard();
//		driver.findElement(By.id("com.nec.biometrics:id/check_in_btn")).click();
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("com.nec.biometrics:id/snackbar_text"))));
//		String checkInresponse2 = driver.findElement(By.id("com.nec.biometrics:id/snackbar_text")).getAttribute("text");
//		System.out.println(checkInresponse2);
		
		Thread.sleep(6000);

	}

}
