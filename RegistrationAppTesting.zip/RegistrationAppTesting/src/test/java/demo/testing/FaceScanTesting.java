package demo.testing;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class FaceScanTesting extends BaseClass {

	@Test
	public void faceScanTest() throws InterruptedException {

		System.out.println("Installing qa-app on device");
		// configure parameters
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/config_sdk_params_btn")).click();
		System.out.println("Configuring SDK parameters...");
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/domain_url_edt"))
				.sendKeys("https://sdkgltenant.qa2.dev.dpf.necam.dev/idms");
		driver.findElement(By.id("com.nec.biometrics:id/user_id_edt")).sendKeys("mobilegluser");
		driver.findElement(By.id("com.nec.biometrics:id/user_pass_edt")).sendKeys("P@ssword1");
		driver.findElement(By.id("com.nec.biometrics:id/dictionary_url_edt"))
				.sendKeys("https://webserver.qa2.dev.dpf.necam.dev/neoface");
		driver.findElement(By.id("com.nec.biometrics:id/username_edt")).sendKeys("ndp");
		driver.findElement(By.id("com.nec.biometrics:id/pass_edt")).sendKeys("Passw0rd!");
		driver.findElement(By.id("com.nec.biometrics:id/livenessTypeSpinner")).sendKeys("NFGL");

		// save configuration
		driver.findElement(By.id("com.nec.biometrics:id/save_btn")).click();

		// click SDK INIT button
		driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();

		System.out.println("The dictionary files will take some time to download, So Please wait...");

		WebElement ele1 = driver.findElement(By.id("com.nec.biometrics:id/download_status_tv"));

		// waiting until the dictionary file download

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(600));

		if (ele1.isDisplayed() == true) {
			wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
			Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");
		} else if (driver.findElement(By.id("com.nec.biometrics:id/alertTitle")).isDisplayed() == true) {
			driver.findElement(By.id("android:id/button2")).click();
			System.out.println("The dictionary files will take some time to download, So Please wait...");
			driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();
			wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
			Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");
		} else {
			System.out.println("App terminated due to poor network...");
		}

		// Face scan
		driver.findElement(By.xpath("(//android.widget.Button[@resource-id='com.nec.biometrics:id/scan_btn'])[1]"))
				.click();

		driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_foreground_only_button"))
				.click();

		System.out.println("Scan your face...");

		wait.until(ExpectedConditions.textToBePresentInElementLocated(By.xpath(
				"//android.widget.TextView[@resource-id=\"com.nec.biometrics:id/face_scan_feedback\" and @text=\"Success\"]"),
				"Success"));

		driver.findElement(By.id("com.nec.biometrics:id/useBtn")).click();

		System.out.println("Scanned your face successfullly!");

		Thread.sleep(3000);

	}

}
