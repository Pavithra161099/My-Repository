package demo.testing;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class DocScanTesting extends BaseClass {

	@Test
	public void docScanTest() throws InterruptedException {

		System.out.println("Installing qa-app on device");
		// configure parameters
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/config_sdk_params_btn")).click();
		System.out.println("Configuring SDK parameters...");
		driver.findElement(AppiumBy.id("com.nec.biometrics:id/domain_url_edt"))
				.sendKeys("https://sdkgltenant.ndpapp2.necdp.com/idms");
		driver.findElement(By.id("com.nec.biometrics:id/user_id_edt")).sendKeys("mobilegluser");
		driver.findElement(By.id("com.nec.biometrics:id/user_pass_edt")).sendKeys("P@ssword1");
		driver.findElement(By.id("com.nec.biometrics:id/dictionary_url_edt"))
				.sendKeys("https://webserver.ndpapp2.necdp.com/neoface");
		driver.findElement(By.id("com.nec.biometrics:id/username_edt")).sendKeys("ndp");
		driver.findElement(By.id("com.nec.biometrics:id/pass_edt")).sendKeys("Passw0rd!");
		driver.findElement(By.id("com.nec.biometrics:id/livenessTypeSpinner")).sendKeys("NFGL");

		// save configuration
		driver.findElement(By.id("com.nec.biometrics:id/save_btn")).click();

		// click SDK INIT button
		driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();

		System.out.println("The dictionary files will take some time to download, So Please wait...");

		WebElement ele1 = driver.findElement(By.id("com.nec.biometrics:id/download_status_tv"));

		// waiting until the dictionary file download

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(600));

		if (ele1.isDisplayed() == true) {
			wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
			Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");
		} else if (driver.findElement(By.id("com.nec.biometrics:id/alertTitle")).isDisplayed() == true) {
			driver.findElement(By.id("android:id/button2")).click();
			System.out.println("The dictionary files will take some time to download, So Please wait...");
			driver.findElement(By.id("com.nec.biometrics:id/next_btn")).click();
			wait.until(ExpectedConditions.textToBePresentInElement(ele1, "Dictionary files download: 100%"));
			Assert.assertEquals(ele1.getText(), "Dictionary files download: 100%");
		} else {
			System.out.println("App terminated due to poor network...");
		}

		// Document scan
		driver.findElement(By.xpath("(//android.widget.Button[@resource-id='com.nec.biometrics:id/scan_btn'])[2]"))
				.click();

		driver.findElement(By.id("com.nec.biometrics:id/passport_scan")).click();

		WebElement ele2 = driver.findElement(By.id("com.nec.biometrics:id/title_view"));

		// waiting until the document file to be downloaded
		System.out.println("The document scan DB files are downloading, So Please wait for a while...");

		wait.until(ExpectedConditions.textToBePresentInElement(ele2, "Doc scan DB downloading: 100%"));

		Thread.sleep(3000);
		wait.until(ExpectedConditions
				.visibilityOf(driver.findElement(By.id("com.android.permissioncontroller:id/permission_message"))));

		driver.findElement(By.id("com.android.permissioncontroller:id/permission_allow_foreground_only_button"))
				.click();

		System.out.println("Downloading done and waiting for document scanning.....");
		System.out.println("Scan your Passport/Driver license...");

		wait.until(ExpectedConditions
				.visibilityOfElementLocated((By) driver.findElement(By.id("com.nec.biometrics:id/buttonsLayout"))));

		// wait.until(ExpectedConditions.presenceOfElementLocated((By)
		// driver.findElement(By.id("com.nec.biometrics:id/buttonsLayout"))));

		if (driver.findElement(By.id("com.nec.biometrics:id/buttonsLayout")).isDisplayed()) {
			wait.until(
					ExpectedConditions.visibilityOfElementLocated((By) driver.findElement(By.id("com.nec.biometrics:id/mainStatusTv"))));
			System.out.println("Please wait for document scanning.....");
			wait.until(ExpectedConditions
					.visibilityOfElementLocated((By) driver.findElement(By.id("com.nec.biometrics:id/currentStatusTv"))));
			Thread.sleep(3000);
			wait.until(ExpectedConditions.textToBePresentInElementLocated(
					By.id("com.nec.biometrics:id/currentStatusTv"), "Please provide the next page"));
			System.out.println("Scanned document successfully!");
		} else {
			System.out.println("Document NOT Scanned Successfully!");
			Thread.currentThread().getStackTrace();
		}

		Thread.sleep(5000);

		if (driver.findElement(By.id("com.nec.biometrics:id/passport_preview_screen")).isDisplayed() == true) {

			System.out
					.println("First name: " + driver.findElement(By.id("com.nec.biometrics:id/first_name")).getText());
			System.out.println("Last name: " + driver.findElement(By.id("com.nec.biometrics:id/last_name")).getText());
			System.out.println(
					"Date of Birth: " + driver.findElement(By.id("com.nec.biometrics:id/date_of_birth")).getText());
			System.out.println(
					"Nationality: " + driver.findElement(By.id("com.nec.biometrics:id/nationality_value")).getText());
			System.out.println(
					"Country Issued: " + driver.findElement(By.id("com.nec.biometrics:id/country_issued")).getText());
			System.out.println(
					"Expiry Date: " + driver.findElement(By.id("com.nec.biometrics:id/date_of_expiration")).getText());
		}

		Thread.sleep(2000);

		driver.findElement(By.id("com.nec.biometrics:id/doc_use")).click();

		Thread.sleep(3000);

	}

}
