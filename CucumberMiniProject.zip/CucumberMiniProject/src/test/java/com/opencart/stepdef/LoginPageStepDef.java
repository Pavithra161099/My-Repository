package com.opencart.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.opencart.pages.LoginPage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginPageStepDef {

	public WebDriver driver = new ChromeDriver();
	private LoginPage loginPage;

	@Before
	public void setUp() throws Exception {
		System.setProperty("websriver.chrome.driver",
				"//Users//vijaya.bonthu//Downloads//chromedriver-mac-x64//chromedriver");
		driver = new ChromeDriver();
	}

	@After
	public void tearDown() throws Exception {
		if (driver != null) {
			driver.quit();
		}
	}

	@Given("Open opencart website and goto login page")
	public void openOpencartWebsiteAndGotoLoginPage() {

		driver.get("https://naveenautomationlabs.com/opencart/");
		loginPage = new LoginPage(driver);

	}

	@Given("Entering valid email and password")
	public void enteringValidEmailAndPassword() {
		loginPage.enterEmailInput("preethi161099@gmai.com");
		loginPage.enterPasswordInput("PaVi@161099");
	}

	@When("I click on login button")
	public void iClickOnLoginButton() {
		loginPage.clickLoginButton();
	}

	@Then("i should be loggged in successfully")
	public void iShouldBeLogggedInSuccessfully() {
		Assert.assertEquals(loginPage.checkLogoutButtonLink(), true);
	}

	@Given("Entering an invalid {string} and {string}")
	public void enteringAnInvalidAnd(String email, String pwd) {
		loginPage.enterEmailInput(email);
		loginPage.enterPasswordInput(pwd);
	}

	@Then("I verify the {string} in step")
	public void iVerifyTheInStep(String string) {
		Assert.assertEquals(driver.findElements(By.xpath("//div[@class='alert alert-danger alert-dismissible']")),
				true);
	}

	@When("I click on {string} link")
	public void iClickOnLink(String string) {
		loginPage.clickforgottenPasswordButton();
	}

	@Then("I should be redirected to the Password reset page")
	public void iShouldBeRedirectedToThePasswordResetPage() {
		Assert.assertTrue(loginPage.forgotPwdPageUrl().contains("Forgotten"));
	}

}
