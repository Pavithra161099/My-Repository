package Runner;

import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;

@CucumberOptions(features = "src/test/resources/features", dryRun = !true, snippets = SnippetType.CAMELCASE, monochrome = true, glue = {
		"com.opencart.stepdef" }, publish = true

)

public class TestRunner extends AbstractTestNGCucumberTests {

	@Override
	@DataProvider()
	public Object[][] scenarios() {
		return super.scenarios();
	}

}
