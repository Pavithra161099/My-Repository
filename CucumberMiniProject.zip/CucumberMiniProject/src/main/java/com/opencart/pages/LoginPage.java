package com.opencart.pages;

import org.jspecify.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	private WebDriver driver;

	// constructor
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	// By locators

	private By emailInputLocator = By.name("email");
	private By passwordInputLocator = By.name("password");
	private By loginButtonLocator = By.xpath("//input[@value='Login']");
	private By forgottenPasswordLinkLocator = By.xpath("(//a[@class='list-group-item'])[3]");
	private By logoutButtonLocator = By.linkText("Logout");

	// Page Methods
	public void enterEmailInput(String email) {
		WebElement enterEmail = driver.findElement(emailInputLocator);
		enterEmail.sendKeys(email);

	}

	public void enterPasswordInput(String password) {
		WebElement enterpwd = driver.findElement(passwordInputLocator);
		enterpwd.sendKeys(password);

	}

	public void clickLoginButton() {
		driver.findElement(loginButtonLocator).click();

	}

	public boolean checkForgotPwdLink() {
		return driver.findElement(forgottenPasswordLinkLocator).isDisplayed();
	}

	public void clickforgottenPasswordButton() {
		driver.findElement(forgottenPasswordLinkLocator).click();

	}

	public boolean checkLogoutButtonLink() {
		return driver.findElement(logoutButtonLocator).isDisplayed();
	}

	public void clickLogoutButton() {
		driver.findElement(logoutButtonLocator).click();

	}

	public void doLogin(String email, String password) {
		enterEmailInput(email);
		enterPasswordInput(password);
		clickLoginButton();
	}

	public String forgotPwdPageUrl() {
		String fogotPwdurl = driver.getCurrentUrl();
		return fogotPwdurl;

	}

}
