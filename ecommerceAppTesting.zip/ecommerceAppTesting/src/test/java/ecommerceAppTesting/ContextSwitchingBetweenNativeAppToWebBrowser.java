package ecommerceAppTesting;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class ContextSwitchingBetweenNativeAppToWebBrowser extends BaseClass {

	@Test
	private void contextSwitchingBetweenNativeAppToWebBrowser() throws InterruptedException {

		// name field
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Pavithra");
		driver.hideKeyboard();

		// select gender
		driver.findElement(By.id("com.androidsample.generalstore:id/radioFemale")).click();

		// select country
		driver.findElement(By.id("android:id/text1")).click();
		driver.findElement(
				AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Argentina\"));"));
		driver.findElement(
				By.xpath("//android.widget.TextView[@resource-id=\"android:id/text1\" and @text=\"Argentina\"]"))
				.click();

		// click lets shop button
		driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();

		// add to cart first two items
		driver.findElements(By.xpath("//android.widget.TextView[@text='ADD TO CART']")).get(0).click();
		driver.findElements(By.xpath("//android.widget.TextView[@text='ADD TO CART']")).get(0).click();

		// go to cart page
		driver.findElement(By.id("com.androidsample.generalstore:id/appbar_btn_cart")).click();

		Thread.sleep(3000);

		// sum up the items prices
		List<WebElement> productsPrices = driver.findElements(By.id("com.androidsample.generalstore:id/productPrice"));
		int count = productsPrices.size();
		double sum = 0;
		for (int i = 0; i < count; i++) {
			String amountString = productsPrices.get(i).getText();
			// $160.97-> 160.97
			double prices = Double.parseDouble(amountString.substring(1));
			sum += prices;

		}

		// sum prices comparing with total purchase amount
		String totalAmount = driver.findElement(By.id("com.androidsample.generalstore:id/totalAmountLbl")).getText();
		double totalPurchaseAmount = Double.parseDouble(totalAmount.substring(1));
		AssertJUnit.assertEquals(totalPurchaseAmount, sum);

		// click check box
		driver.findElement(By.className("android.widget.CheckBox")).click();

		WebElement termsAndCondn = driver.findElement(By.id("com.androidsample.generalstore:id/termsButton"));
		longClick(termsAndCondn);

		AssertJUnit.assertEquals(driver.findElement(By.id("com.androidsample.generalstore:id/alertTitle")).getText(),
				"Terms Of Conditions");
		driver.findElement(By.id("android:id/button1")).click();

		// visit to the webpage to complete purchase
		driver.findElement(By.id("com.androidsample.generalstore:id/btnProceed")).click();

		Thread.sleep(6000);

		Set<String> contexts = driver.getContextHandles();

		for (String contextName : contexts) {
			System.out.println(contextName);
		}
		// NATIVE_APP
		// WEBVIEW_com.androidsample.generalstore

		driver.context("WEBVIEW_com.androidsample.generalstore"); // changed context from native app to webview
		driver.findElement(By.name("q")).sendKeys("rahul shetty academy", Keys.ENTER);// need to chromedriver path in
																						// base class otherwise will get
																						// an error
		driver.pressKey(new KeyEvent(AndroidKey.BACK));
		driver.context("NATIVE_APP");

		Thread.sleep(6000);

	}

}
