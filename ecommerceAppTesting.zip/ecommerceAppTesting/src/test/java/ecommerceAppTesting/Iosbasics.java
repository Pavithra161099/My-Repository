package ecommerceAppTesting;

import org.testng.annotations.Test;

public class Iosbasics extends iOSBaseClass{
	
	@Test
	public void basicTest() {
		
	}

}
