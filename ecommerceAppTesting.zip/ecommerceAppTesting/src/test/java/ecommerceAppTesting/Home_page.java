package ecommerceAppTesting;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class Home_page extends BaseClass {

	@Test
	public void fillForm() throws InterruptedException {

		// name field
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Pavithra");
		driver.hideKeyboard();

		// select gender
		driver.findElement(By.id("com.androidsample.generalstore:id/radioFemale")).click();

		// select country
		driver.findElement(By.id("android:id/text1")).click();
		driver.findElement(
				AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Argentina\"));"));
		driver.findElement(
				By.xpath("//android.widget.TextView[@resource-id=\"android:id/text1\" and @text=\"Argentina\"]"))
				.click();

		// click lets shop button
		driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();

		// toast message handling
//		String toastmsg = driver.findElement(By.xpath("//android.widget.Toast[@text=\"Please enter your name\"]"))
//				.getAttribute("text");
//		Assert.assertEquals(toastmsg, "Please enter your name");
		
		
		Thread.sleep(2000);

	}

}
