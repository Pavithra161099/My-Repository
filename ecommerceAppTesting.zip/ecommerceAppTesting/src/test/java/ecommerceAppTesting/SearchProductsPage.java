package ecommerceAppTesting;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class SearchProductsPage extends BaseClass {

	@Test
	private void searchProduct() throws InterruptedException {

		// name field
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Pavithra");
		driver.hideKeyboard();

		// select gender
		driver.findElement(By.id("com.androidsample.generalstore:id/radioFemale")).click();

		// select country
		driver.findElement(By.id("android:id/text1")).click();
		driver.findElement(
				AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Argentina\"));"));
		driver.findElement(
				By.xpath("//android.widget.TextView[@resource-id=\"android:id/text1\" and @text=\"Argentina\"]"))
				.click();

		// click lets shop button
		driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();

		// search product
		driver.findElement(AppiumBy
				.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Jordan Lift Off\"));"));
		int productCount = driver.findElements(By.id("com.androidsample.generalstore:id/productName")).size();

		for (int i = 0; i < productCount; i++) {
			String productName = driver.findElements(By.id("com.androidsample.generalstore:id/productName")).get(i)
					.getText();

			if (productName.equals("Jordan Lift Off")) {
				// click add to cart button
				driver.findElements(By.id("com.androidsample.generalstore:id/productAddCart")).get(i).click();
			}
		}
		// go to cart page
		driver.findElement(By.id("com.androidsample.generalstore:id/appbar_btn_cart")).click();
		// wait untill the cart page loaded...
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement ele = driver.findElement(By.id("com.androidsample.generalstore:id/toolbar_title"));
//		wait.until(ExpectedConditions.visibilityOf(ele));
		wait.until(ExpectedConditions.attributeContains(ele, "text", "Cart"));
		Assert.assertEquals(driver.findElement(By.id("com.androidsample.generalstore:id/productName")).getText(),
				"Jordan Lift Off");

		Thread.sleep(3000);

	}

}
