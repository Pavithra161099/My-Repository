package ecommerceAppTesting;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class SumOfFirstTwoProducts extends BaseClass {

	@Test
	private void sumOfFirstTwoProducts() throws InterruptedException {

		// name field
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Pavithra");
		driver.hideKeyboard();

		// select gender
		driver.findElement(By.id("com.androidsample.generalstore:id/radioFemale")).click();

		// select country
		driver.findElement(By.id("android:id/text1")).click();
		driver.findElement(
				AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Argentina\"));"));
		driver.findElement(
				By.xpath("//android.widget.TextView[@resource-id=\"android:id/text1\" and @text=\"Argentina\"]"))
				.click();

		// click lets shop button
		driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();

		// add to cart first two items
		driver.findElements(By.xpath("//android.widget.TextView[@text='ADD TO CART']")).get(0).click();
		driver.findElements(By.xpath("//android.widget.TextView[@text='ADD TO CART']")).get(0).click();

		// go to cart page
		driver.findElement(By.id("com.androidsample.generalstore:id/appbar_btn_cart")).click();
		
		Thread.sleep(3000);
		// wait untill the cart page loaded...
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
////		wait.until(ExpectedConditions
////				.visibilityOf(driver.findElement(By.id("com.androidsample.generalstore:id/toolbar_title"))));
//		wait.until(ExpectedConditions.attributeContains(
//				driver.findElement(By.id("com.androidsample.generalstore:id/toolbar_title")), "text", "Cart"));

		// sum up the items prices
		List<WebElement> productsPrices = driver.findElements(By.id("com.androidsample.generalstore:id/productPrice"));
		int count = productsPrices.size();
		double sum = 0;
		for (int i = 0; i < count; i++) {
			String amountString = productsPrices.get(i).getText();
			// $160.97-> 160.97
			double prices = Double.parseDouble(amountString.substring(1));
			sum += prices;

		}

		// sum prices comparing with total purchase amount
		String totalAmount = driver.findElement(By.id("com.androidsample.generalstore:id/totalAmountLbl")).getText();
		double totalPurchaseAmount = Double.parseDouble(totalAmount.substring(1));
		Assert.assertEquals(totalPurchaseAmount, sum);

		// click check box
		driver.findElement(By.className("android.widget.CheckBox")).click();

		WebElement termsAndCondn = driver.findElement(By.id("com.androidsample.generalstore:id/termsButton"));
		longClick(termsAndCondn);
		
		Assert.assertEquals(driver.findElement(By.id("com.androidsample.generalstore:id/alertTitle")).getText(),
				"Terms Of Conditions");
		driver.findElement(By.id("android:id/button1")).click();
		
		// visit to the webpage to complete purchase
		driver.findElement(By.id("com.androidsample.generalstore:id/btnProceed")).click();

		Thread.sleep(3000);

	}

}
