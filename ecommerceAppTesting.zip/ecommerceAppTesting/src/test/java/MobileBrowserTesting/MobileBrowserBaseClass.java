package MobileBrowserTesting;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class MobileBrowserBaseClass {

	AndroidDriver driver;

	@BeforeClass
	public void setUp() throws MalformedURLException {

		UiAutomator2Options option = new UiAutomator2Options();
//		option.setDeviceName("emulator1");
		option.setDeviceName("Android Device");
		option.setChromedriverExecutable("//Users//vijaya.bonthu//Downloads//chromedriver-mac-x64//chromedriver");
		option.setCapability("browserName", "Chrome");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	

	@AfterClass
	private void tearDown() {

		driver.quit();
	}
}
