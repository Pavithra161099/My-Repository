package MobileBrowserTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

public class MobileBrowserTesting extends MobileBrowserBaseClass {

	@Test
	private void browserTesting() throws InterruptedException {

//		driver.get("https://www.google.com/");
//		System.out.println(driver.getTitle());
//		driver.findElement(By.name("q")).sendKeys("rahul shetty academy", Keys.ENTER);

		driver.get("https://www.google.com/");
		driver.get("https://rahulshettyacademy.com/angularAppdemo/");
		driver.findElement(By.className("navbar-toggler-icon")).click();
		driver.findElement(By.xpath("//a[@routerlink='/products']")).click();
		// scroll till end
		((JavascriptExecutor) driver).executeScript("window.scrollBy(0,1000)", "");

		String text = driver.findElement(By.xpath("//a[normalize-space(text())='Devops']")).getText();
		Assert.assertEquals(text, "Devops");

		Thread.sleep(3000);

	}

}
