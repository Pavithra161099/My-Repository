package demo.testing;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class IOSBasics extends BaseClass{
	
	@Test
	public void iosBasictest() throws InterruptedException {
		
		/*
		 * In iOS, we can use the following locators
		 * 1. className
		 * 2. id
		 * 3. acccessibilityId
		 * 4. X path
		 * 5. iOS class chain
		 * 6. iOS predicate string- it's very useful to find exact attribute to perform actions
		 */
		
		driver.findElement(AppiumBy.accessibilityId("Alert Views")).click();
		driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == \'Text Entry\'`]")).click();
		driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeCell")).sendKeys("Hello world!");
		driver.findElement(AppiumBy.accessibilityId("OK")).click();
		
		
		//driver.findElement(AppiumBy.iOSNsPredicateString("name == \'Confirm / Cancel\'")).click();
		//driver.findElement(AppiumBy.iOSNsPredicateString("type == 'XCUIElementTypeStaticText' AND value =='Confirm / Cancel'")).click();
		driver.findElement(AppiumBy.iOSNsPredicateString("type == 'XCUIElementTypeStaticText' AND value BEGINSWITH[c] 'Confirm'")).click();
		//driver.findElement(AppiumBy.iOSNsPredicateString("type == 'XCUIElementTypeStaticText' AND value ENDSWITH[c] 'Cancel'")).click();
		String text = driver.findElement(AppiumBy.iOSNsPredicateString("name BEGINSWITH[c] 'A message'")).getText();
		System.out.println(text);
		
		
		driver.findElement(AppiumBy.iOSNsPredicateString("name == \'Confirm\'")).click();
		
		
		Thread.sleep(2000);
		
	}

}
