package demo.testing;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumBy;

public class IOSSlider extends BaseClass{
	
	@Test
	public void iosSliderTest() throws InterruptedException {
		
		/*
		 * 1. Add the TestApp 3.app under resource and set the app in option.setApp("");
		 * 2. add the ios class chain of slider
		 */

		
		WebElement slider = driver.findElement(AppiumBy.iOSClassChain("**/XCUIElementTypeSlider[`lable === 'AppElem'`]"));
		
		slider.sendKeys("0%");// previously it was set the value with setValue(), but now we can use sendKeys() method
		
		Assert.assertEquals("0%", slider.getAttribute("value"));
		
		Thread.sleep(3000);
		
		slider.sendKeys("1%");
		
		Assert.assertEquals("1%", slider.getAttribute("value"));
		
        Thread.sleep(3000);
		
		slider.sendKeys("0.5%");
		
		Assert.assertEquals("0.5%", slider.getAttribute("value"));
		
	}

}
