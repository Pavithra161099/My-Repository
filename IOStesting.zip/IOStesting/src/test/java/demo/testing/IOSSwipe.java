package demo.testing;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

public class IOSSwipe extends BaseClass{
	
	@Test
	public void iosSwipeTest() throws InterruptedException {
		
		/*
		 * 1. get bundle id of existing applications in iPhone by search on "bundle id for IOS photos application"
		 * 2. get the bundle id for which application to be automated and use it in script
		 * 
		 */

		
		Map<String, String> params = new HashMap<String, String>();
		params.put("bundleId", "com.apple.mobileslideshow");
		
		driver.executeScript("mobile:launchApp", params);
		
		
	}

}
