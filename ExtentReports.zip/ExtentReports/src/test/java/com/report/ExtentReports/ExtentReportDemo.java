package com.report.ExtentReports;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportDemo {

	ExtentReports extent;
	ChromeDriver driver;

	@BeforeTest
	public void config() {

		// ExtentReports, ExtentSparkReporter
		String path = System.getProperty("user.dir") + "//Testresults//index.html";
		ExtentSparkReporter reporter = new ExtentSparkReporter(path);
		reporter.config().setDocumentTitle("Test Results");
		reporter.config().setReportName("Web automation results");

		extent = new ExtentReports();
		extent.attachReporter(reporter);
		extent.setSystemInfo("Tester", "Pavithra");
		extent.createTest("Initial Demo");

	}

	@Test
	public void initialDemo() throws InterruptedException {

		ExtentTest test = extent.createTest("Initial Demo");
		System.setProperty("webdriver.chrome.driver",
				"//Users//vijaya.bonthu//Downloads//chromedriver-mac-x64//chromedriver");

		ChromeDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.out.println(driver.getTitle());
		driver.close();
		test.addScreenCaptureFromPath(System.getProperty("user.dir") + "//Testresults//screenshot1.png");
		test.fail("Result do not match");
	
		extent.flush();

		driver.quit();

	}

}
