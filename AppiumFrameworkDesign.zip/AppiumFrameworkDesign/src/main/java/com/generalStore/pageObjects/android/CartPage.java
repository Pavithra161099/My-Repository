package com.generalStore.pageObjects.android;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import CommonAppiumActions.utils.AppiumCommonActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class CartPage extends AppiumCommonActions {

	AndroidDriver driver;

	public CartPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
	}

	@AndroidFindBy(id = "com.androidsample.generalstore:id/productPrice")
	private List<WebElement> productList;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/totalAmountLbl")
	private WebElement totalAmount;

	@AndroidFindBy(className = "android.widget.CheckBox")
	private WebElement acceptButton;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/termsButton")
	private WebElement termsAndCondn;

	@AndroidFindBy(id = "android:id/button1")
	private WebElement closePopup;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnProceed")
	private WebElement proceedBtn;

	
	public List<WebElement> getProductList(){
		return productList;
	}
	public Double getProductSum() {
		int count = productList.size();
		double sum = 0;
		for (int i = 0; i < count; i++) {
			String amountString = productList.get(i).getText();
			Double prices = getFormattedAmount(amountString);
			sum += prices;
		}
		return sum;
	}

	public Double totalDisplayAmount() {
		return getFormattedAmount(totalAmount.getText());

	}

	public void acceptButton() {
		acceptButton.click();
		
	}

	public void termsAndCondn() {
		longClick(termsAndCondn);
		Assert.assertEquals(driver.findElement(By.id("com.androidsample.generalstore:id/alertTitle")).getText(),
				"Terms Of Conditions");
		closePopup.click();
	}


	public void proceedBtn() throws InterruptedException {
		proceedBtn.click();
		Thread.sleep(6000);
	}

}
