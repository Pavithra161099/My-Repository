package com.generalStore.pageObjects.android;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import CommonAppiumActions.utils.AppiumCommonActions;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class FormPage extends AppiumCommonActions {

	AndroidDriver driver;

	public FormPage(AndroidDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(this.driver), this);
	}

	@AndroidFindBy(id = "com.androidsample.generalstore:id/nameField")
	private WebElement namefield;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/radioFemale")
	private WebElement femaleGenderOption;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/radioMale")
	private WebElement maleGenderOption;

	@AndroidFindBy(id = "android:id/text1")
	private WebElement selectCountry;

	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnLetsShop")
	private WebElement letsShop;

	public void setNameField(String name) {
		namefield.sendKeys(name);
		driver.hideKeyboard();
	}

	public void setGenderOption(String gender) {

		if (gender.equals("Female"))
			femaleGenderOption.click();
		else
			maleGenderOption.click();
	}

	public void selectCountry(String countryName) {
		selectCountry.click();
		scrollToText(countryName);
		driver.findElement(By.xpath(
				"//android.widget.TextView[@resource-id=\"android:id/text1\" and @text=\"" + countryName + "\"]"))
				.click();
	}

	public ProductsCatalogue letsShopButton() {
		letsShop.click();
		return new ProductsCatalogue(driver);
	}

}
