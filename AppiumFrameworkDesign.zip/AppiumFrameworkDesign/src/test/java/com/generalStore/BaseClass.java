package com.generalStore;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class BaseClass {

	AndroidDriver driver;

	@BeforeClass
	public void setUp() throws MalformedURLException {

		UiAutomator2Options option = new UiAutomator2Options();
		option.setDeviceName("emulator1");
//		option.setDeviceName("Android Device");
		option.setChromedriverExecutable("//Users//vijaya.bonthu//Downloads//chromedriver-mac-x64//chromedriver");
		option.setApp(
				"//Users//vijaya.bonthu//eclipse-workspace//ecommerceAppTesting//src//test//java//resources//General-Store.apk");

		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), option);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}
	public void longClick(WebElement ele) {
		((JavascriptExecutor) driver).executeScript("mobile:longClickGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) ele).getId(), "duration", 2000));

	}

	@AfterClass
	private void tearDown() {

		driver.quit();
	}

}
