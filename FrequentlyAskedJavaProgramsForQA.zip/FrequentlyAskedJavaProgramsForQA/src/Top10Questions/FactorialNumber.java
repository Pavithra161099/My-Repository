package Top10Questions;

import java.util.Scanner;

public class FactorialNumber {

	public static void main(String[] args) {

		// Factorial num = 5!= 1*2*3*4*5= 120

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = scan.nextInt();
		int fact = 1;
		for (int i = 1; i <= num; i++) {
			fact = fact * i;
		}
		System.out.println("The Factorial of " + num + " is: " + fact);
	}

}
