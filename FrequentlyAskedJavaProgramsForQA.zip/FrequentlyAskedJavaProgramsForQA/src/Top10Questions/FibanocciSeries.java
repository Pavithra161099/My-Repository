package Top10Questions;

import java.util.Iterator;

public class FibanocciSeries {

	public static void main(String[] args) {

		// In Fibanocci Series, next number is the sum of previous two numbers
		// 0,1,1,2,3,5,8,13,21,34, 55,etc....

		int n1 = 0, n2 = 1, num = 10;
		for (int i = 0; i <= num; i++) {
			System.out.print(n1 + " ");
			int sum = n1 + n2;
			n1 = n2;
			n2 = sum;
		}

	}

}
