package Top10Questions;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {

		// Armstrong number is a number that is equal to sum of cubes of it's digits
		// Input :153 output:yes
		// logic: 153 is a Armstrong number ==> (1*1*1)+(5*5*5)+(3*3*3)=1+125+27= 153

		Scanner scan = new Scanner(System.in);
		System.out.print("enter a number: "); //23
		int num = scan.nextInt();
		int sum = 0, res, temp;
		temp = num;

		while (num > 0) { //23>0 yes
			res = num % 10; //res =23%10 = 3
			num = num / 10; //num = 23/10 = 2
			sum = sum + (res * res * res); //3*3*3
		}

		if (temp == sum)
			System.out.println(temp + " is a Armstrong number");
		else
			System.out.println(temp + " is not a Armstrong number");
	}

}
