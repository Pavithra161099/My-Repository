package Top10Questions;

import java.util.ArrayList;
import java.util.Collections;

public class FindingLargestNumberFrom3Numbers {

	public static void main(String[] args) {

//		//1. Using if else method
//		int n1 = 20, n2 = 10, n3 = 40;
//
//		if (n1 > n2 && n1 > n3) {
//			System.out.println("N1 is greater");
//		} else if (n2 > n1 && n2 > n3) {
//			System.out.println("N2 is greater");
//		} else {
//			System.out.println("N3 is greater");
//		}

		// 2. using Colllections.max()
		ArrayList<Integer> n = new ArrayList<Integer>();
		n.add(1010);
		n.add(40);
		n.add(90);
		n.add(120);
		System.out.println(Collections.max(n) + " is the largest number");

	}

}
