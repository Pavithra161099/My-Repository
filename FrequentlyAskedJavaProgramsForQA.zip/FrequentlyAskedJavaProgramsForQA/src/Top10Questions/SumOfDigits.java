package Top10Questions;

import java.util.Scanner;

public class SumOfDigits {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int n = scan.nextInt();

		int sum = 0;
		while (n != 0) {
			sum = sum + n % 10; //sum = 0+ 11%10= sum =1, sum = 1+ 1=2
			n = n / 10;// n=11/10 =1, 1/10=0
		}
		System.out.print("Sum of digit of " + n + " is: " + sum);

		scan.close();
	}

}
