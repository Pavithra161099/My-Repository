package Top10Questions;

public class SwapTwoNumbers {

	public static void main(String[] args) {

		int a = 10;
		int b = 20;
		int temp;
		System.out.println("Before Swapping: a = " + a + " and b = " + b);

		// 1. using three variables
		temp = a;
		a = b;
		b = temp;

		// 2. using two variables
//		a = a + b;// a=30
//		b = a - b;// b=30-20= 10
//		a = a - b; // b= 30-10 =20

		// 3. Swapping a and b using XOR
//		a = a ^ b;
//		b = a ^ b;
//		a = a ^ b;

		System.out.println("After Swapping: a = " + a + " and b = " + b);
	}

}
