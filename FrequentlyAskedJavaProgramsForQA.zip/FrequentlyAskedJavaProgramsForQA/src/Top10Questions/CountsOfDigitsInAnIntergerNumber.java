package Top10Questions;

import java.util.Scanner;

public class CountsOfDigitsInAnIntergerNumber {

	public static void main(String[] args) {

//		Scanner scan = new Scanner(System.in);
//		System.out.print("Enter a number: ");
//		long n = scan.nextInt(); //n= 123
//		int count = 0;
//		while (n != 0) {
//			n = n / 10;// n=123/10= 12, n=12/10=1, n=1/10=0
//			count++; ///count=1,2,3
//		}
//		System.out.println("Number of digits : " + count);
//
//		scan.close();

		// 2.converting given number to string to count digits in an interger
		int num = 123456789;
		String result = Integer.toString(num);
		System.out.println(result.length());
	}

}
