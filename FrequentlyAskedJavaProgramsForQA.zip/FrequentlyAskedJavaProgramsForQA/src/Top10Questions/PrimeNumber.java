package Top10Questions;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {

		// prime number is a number which is divisible by 1 and itself only.

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int n = scan.nextInt();
		int count = 0;
		if (n <= 1) {
			System.out.println("The number is not a prime number");
			return;
		}
		for (int i = 2; i <= n; i++) {
			if (n % i == 0) {
				count++;
			}
		}
		if (count >1) {
			System.out.println("The number is not a prime number");
		} else {
			System.out.println("The number is a prime number");
		}

		// prime number
//		Scanner scan = new Scanner(System.in);
//
//		System.out.print("Enter a number: ");
//		int n = scan.nextInt();
//		for (int i = 1; i <= n; i++) {
//			int count = 0;
//			for (int j = 1; j <= i; j++) {
//				if (i % j == 0) {
//					count++;
//				}
//			}
//			if (count == 2) {
//				System.out.print("The prime numbers found between from 1 to " + n + " is: " + i);
//				System.out.println();
//			}
//			
//		}
		scan.close();

	}

}
