package Top10Questions;

import java.util.Scanner;

public class ReverseANumbersAndNumberIsPalindromeOrNot {

	public static void main(String[] args) {
		/*
		 * The palindrome number in Java is a number that stays when all its digits are
		 * reversed. Example: input- 12321 output: 12321
		 */

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = scan.nextInt();
		int temp = num;
		int rev = 0, rem;

		while (num > 0) {
			rem = num % 10;
			rev = (rev * 10) + rem;
			num = num / 10;

		}
		System.out.println("Reversed number is: " + rev);
		// verify the number is palindrome or not
		if (temp == rev)
			System.out.println("Palindrome number");
		else
			System.out.println("Not Palindrome");

	}

}
