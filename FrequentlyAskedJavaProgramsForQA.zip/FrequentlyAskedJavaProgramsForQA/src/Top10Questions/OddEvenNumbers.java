package Top10Questions;

import java.util.Scanner;

public class OddEvenNumbers {

	public static void main(String[] args) {

		// odd/even numbers find out

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = scan.nextInt();
		if (num % 2 == 0)
			System.out.println("The Given number " + num + " is Even Number");
		else
			System.out.println("The Given number " + num + " is Odd Number");

		scan.close();

	}

}
