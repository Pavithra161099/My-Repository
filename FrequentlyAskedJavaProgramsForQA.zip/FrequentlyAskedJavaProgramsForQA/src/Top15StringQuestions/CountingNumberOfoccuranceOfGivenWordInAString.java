package Top15StringQuestions;

public class CountingNumberOfoccuranceOfGivenWordInAString {

	public static void main(String[] args) {

		String str = "Java is a programming language. Java is widely used in software testing";
		String[] words = str.toLowerCase().split(" ");
		String word = "java";
		int occurences = 0;
		for (int i = 0; i < words.length; i++) {
			if (words[i].equals(word)) {
				occurences++;
			}
		}
		System.out.println("The Word of " + word + " is occured: " + occurences + " times");
	}
}
