package Top15StringQuestions;

import java.util.Scanner;

public class RemoveASpaceFromGivenString {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a String: ");
		String str = scan.nextLine();
		System.out.println("Original String: " + str);
		str = str.replaceAll(" ", "");
		System.out.println("After removed space: " + str);
		scan.close();
		}

}
