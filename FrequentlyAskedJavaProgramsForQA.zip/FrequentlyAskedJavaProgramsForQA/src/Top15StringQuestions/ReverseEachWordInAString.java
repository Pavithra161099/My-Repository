package Top15StringQuestions;

public class ReverseEachWordInAString {

	public static void main(String[] args) {

		String str = "reverse each word in a string";
		String[] words = str.split(" ");
		String reverseWord = "";
		for (String w : words) {
			StringBuilder sb = new StringBuilder(w);
			sb.reverse();
			reverseWord = reverseWord + sb.toString() + " ";

		}
		System.out.println(reverseWord);
	}

}
