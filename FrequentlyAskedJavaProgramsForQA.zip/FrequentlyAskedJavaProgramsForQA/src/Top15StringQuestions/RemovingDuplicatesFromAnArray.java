package Top15StringQuestions;

public class RemovingDuplicatesFromAnArray {

	public static void main(String[] args) {

		// 1.
		String[] strarr = { "abc", "def", "mno", "xyz", "pqr", "xyz", "pqr" };
		for (int i = 0; i < strarr.length; i++) {
			for (int j = i + 1; j < strarr.length; j++) {
				if (strarr[i] == strarr[j]) {
					System.out.println("Duplicates elements is: " + strarr[j]);
				}

			}
		}
		// 2. using hashset
//		HashSet<String> hs = new HashSet<>();
//		for (String arrayElelment : strarr) {
//			if (!hs.add(arrayElelment)) {
//				System.out.println("Duplicate element: " + arrayElelment);
//			}
//		}

	}

}
