package Top15StringQuestions;

import java.util.Scanner;

public class FindOutDuplicateCharactersFromAString {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a String: ");
		String str = scan.nextLine();
//		String str = "Apple is fruit";
		char[] arr = str.toCharArray();

		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					System.out.print(arr[j] + " ");
					break;
				}
			}

		}
		scan.close();
	}

}
