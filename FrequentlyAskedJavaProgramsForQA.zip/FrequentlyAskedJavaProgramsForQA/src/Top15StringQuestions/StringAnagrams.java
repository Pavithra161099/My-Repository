package Top15StringQuestions;

import java.util.Arrays;
import java.util.Scanner;

public class StringAnagrams {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a String1: ");
		String str1 = scan.nextLine().toLowerCase();
		System.out.print("Enter a String2: ");
		String str2 = scan.nextLine().toLowerCase();

		if (str1.length() == str2.length()) {

			char[] arr1 = str1.toCharArray();
			char[] arr2 = str2.toCharArray();
			Arrays.sort(arr1);
			Arrays.sort(arr2);
			boolean result = Arrays.equals(arr1, arr2);
			if (result)
				System.out.println(str1 + " and " + str2 + " are anagram.");
			else
				System.out.println(str1 + " and " + str2 + " are not anagram.");

		} else {
			System.out.println(str1 + " and " + str2 + " are not anagram.");
		}
		scan.close();
	}

}
