package Top15StringQuestions;

public class SortAnArrayWithoutUsingInbuiltMethod {

	public static void main(String[] args) {

		int temp;
		int arr[] = new int[] { 4, 2, 3, 1, 0, 6, 12, 15, 20 };

		System.out.print("Before sorted: ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}

		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}

		}

		System.out.println();
		System.out.print("After sorted: ");
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i]+" ");
		}
	}

}
