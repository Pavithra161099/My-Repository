package Top15StringQuestions;

import java.util.ArrayList;

public class FindFirstAndLastElelmentOfArrayListInJava {

	public static void main(String[] args) {

		ArrayList<Integer> al = new ArrayList<Integer>();

		al.add(20);
		al.add(60);
		al.add(30);
		al.add(17);
		System.out.print("First Element is: " + al.get(0));
		System.out.println();
		System.out.print("Last Element is: " + al.get(al.size()-1));

	}

}
