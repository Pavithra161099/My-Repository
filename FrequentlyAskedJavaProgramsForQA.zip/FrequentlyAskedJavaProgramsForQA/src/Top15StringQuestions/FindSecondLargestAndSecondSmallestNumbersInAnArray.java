package Top15StringQuestions;

import java.util.Arrays;

public class FindSecondLargestAndSecondSmallestNumbersInAnArray {

	public static void main(String[] args) {

		int arr[] = new int[] { 4, 2, 3, 1, 0, 6, 12, 15, 20 };
		int n = arr.length;
		Arrays.sort(arr);
		System.out.println("Second smallest element is: " + arr[1]);
		System.out.println("Second largest element is: " + arr[n - 2]);

	}

}
