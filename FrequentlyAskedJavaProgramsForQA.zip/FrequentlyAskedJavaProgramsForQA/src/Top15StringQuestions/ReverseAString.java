package Top15StringQuestions;

import java.util.Scanner;

public class ReverseAString {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a String: ");
		String str = scan.nextLine();

		char[] arr1 = str.toCharArray();
		char[] arr2 = new char[arr1.length];

		int j = arr2.length - 1;
		for (int i = 0; i <= arr1.length - 1; i++) {
			arr2[j] = arr1[i];
			j--;
		}

		System.out.print("The reversed string is: " + new String(arr2));
		scan.close();

	}

}
