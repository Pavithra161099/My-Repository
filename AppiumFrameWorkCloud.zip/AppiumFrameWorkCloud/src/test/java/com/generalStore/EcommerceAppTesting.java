package com.generalStore;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import com.generalStore.pageObjects.android.CartPage;
import com.generalStore.pageObjects.android.FormPage;
import com.generalStore.pageObjects.android.ProductsCatalogue;

import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

public class EcommerceAppTesting extends BaseClass {

	@Test(groups = {"reg"})
	private void ecommerceAppTesting() throws InterruptedException {

		FormPage formpage = new FormPage(driver);
		formpage.setNameField("Pavithra");
		formpage.setGenderOption("Female");
		formpage.selectCountry("Argentina");
		
		
		ProductsCatalogue productsCatalogue = formpage.letsShopButton();;
		productsCatalogue.addToCart(0);
		productsCatalogue.addToCart(0);
		
		
		CartPage cartpage = productsCatalogue.goToCartPage();
		Double totalSum = cartpage.getProductSum();
		Double totalDisplaySum= cartpage.totalDisplayAmount();
		AssertJUnit.assertEquals(totalSum, totalDisplaySum);
		cartpage.acceptButton();
		cartpage.termsAndCondn();
		cartpage.proceedBtn();

		Set<String> contexts = driver.getContextHandles();

		for (String contextName : contexts) {
			System.out.println(contextName);
		}
		// NATIVE_APP
		// WEBVIEW_com.androidsample.generalstore

		driver.context("WEBVIEW_com.androidsample.generalstore"); // changed context from native app to webview
		driver.findElement(By.name("q")).sendKeys("rahul shetty academy", Keys.ENTER);// need to chromedriver path in
																						// base class otherwise will get
																						// an error
		driver.pressKey(new KeyEvent(AndroidKey.BACK));
		driver.context("NATIVE_APP");

		Thread.sleep(6000);

	}

}
